#!/usr/bin/env python
# -*- coding: utf-8 -*- #
from __future__ import unicode_literals

AUTHOR = "TCMG 41 Group 6"
SITENAME = "Penguins!"
SITEURL = " "

PATH = "content"

TIMEZONE = "America/New_York"

DEFAULT_LANG = "en"

THEME = "/home/kemal/Documents/GP1/theme/blue/"

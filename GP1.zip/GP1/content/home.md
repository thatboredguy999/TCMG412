Title: All About Pengins
Date: 2021-01-26

Penguins are aquatic birds that primarily live in the southern hemisphere, with only one species presiding north of the equator. Penguins find nutrition by consuming fish, krill, squid, and other small sea creatures. 

The word penguin was first documented in the 16th century in reference to an old species Pinguinus that no longer exists. European explorers came across the southern penguins, they used their word for their northern species. 

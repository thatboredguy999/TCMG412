Title: Species of Penguin
Date: 2021-01-25

Penguin Species Across the Globe

*The largest species of penguin is the emperor penguin, which grows up to about 3ft+ in height, and more than 70 lbs on average.The emporor penguin is located in Antartica and primarily eat fish and small crustaceans. They can remain submerged around 20 minutes, up to a depth of 1,750 feet.

*The smallest species of penguin belong to the genus Eudyptula which is split into two species, Eudyptula minor and Eudyptula novaehollandiae. These penguins are found in Tasmania, New Zealand, and southern Australia. These penguin species are nicknamed little penguin and fairy penguin, respectively. They grow to an average of 13 in in height and weigh about 3.5 lbs. 

*There are currently 18 known species of Penguin!

